def sayhello():
    print("Hello My friends")